// calculator


// let a = 15;
// let b = 5;
// console.log(a+b);
// console.log(a-b);
// console.log(a*b);
// console.log(a/b);


//forloop 

// let string="hello duniya";

// for(let i=0; i<6; i++)
// {
//     console.log(string);

// }



// while loop

// let str ="hello duniya";
// let i=0;
// while(i<9){
//     console.log(str);
//     i++;
// }



// do while loop

// let str="hello";
// let i=0;
// do{
//     i += 1;
//     console.log(str);
// }
// while(i<8)



// continue statement

// let i=0;
// while(i<5){
//     i++;
    
//     console.log(i);
//     continue;
    
// }

// let i=0;
// do{
//     console.log(i);
//     i++;
//     continue;
// }while(i<5);



// Array

// let Arr=[1, 8, 5];
// let arr= Arr.sort();
// for(let i=0; i<Arr.length; i++ ){
//     console.log(Arr[i]);
    
// }


// let arr=["apple", "mango", "banana", "grapes"];

// for(i=0; i<arr.length; i++){
//     console.log(arr[i]);
// }

// let arr=["apppy","frooty","maza"];
// let i=0;
// do{
   
//     console.log(arr[i]);
//     i++;
// }
// while(i<3);


// let arr=["hello", "hi", "yo"];
// let i=0;
// while(i<3){
//     console.log(arr[i]);
//     i++;

// }


// let arr=[1,2,3,4];
// let Arr=arr;
// Arr.push(5);

// console.log(Arr);

// reverse 10 natural Number;
// let i;
// for(i=10; i>0; i--){
//     console.log(i);
// }


// let i=[1,2,3,4,5,];
// console.log(i);



// let i=0;
// for(i=0; i<=1000; i++){
//     if(i%2==1){

//         console.log(i);

//     }
// }


// let i=0;
// do{
//     i++;
//     console.log(i);
// }
// while(i<1000){
//     if(i%=0){
//         console.log(i)
//     }
// }




// nested loop


