
// let i=0;
// do{
//     i++;
//     console.
// }